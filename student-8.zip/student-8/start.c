#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main() {

    /* TBD: Creare la coda di messaggi per
            i messaggi di tipo "connect"
     */

    /* TBD: Creare la coda di messaggi per
            i messaggi di tipo "acknowledge"
     */


    /* TBD: Creare un processo figlio,
            e fargli eseguire il programma "server"
     */

    /* TBD: Creare due processi figli,
            e fargli eseguire il programma "client"
     */

    /* TBD: Attendere la terminazione dei 3 processi figli */

    /* TBD: De-allocare le due code di messaggi */

}